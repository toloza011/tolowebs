<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
 Hola, haz recibido un mensaje de: <b>{{$nombre}}</b>
<p>Nombre: <b>{{$nombre}}</b></p>
<p>Correo: <b>{{$correo}}</b></p>
<p>Numero: <b>{{$numero}}</b></p>
<p>Mensaje: <b>{{$mensaje}}</b></p>
<footer>
    <p style="margin-top: 50px;"><b>ToloWebs 2020</b></p>
</footer>
</body>
</html>