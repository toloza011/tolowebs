<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
 Hola, haz recibido un mensaje de: <b><?php echo e($nombre); ?></b>
<p>Nombre: <b><?php echo e($nombre); ?></b></p>
<p>Correo: <b><?php echo e($correo); ?></b></p>
<p>Numero: <b><?php echo e($numero); ?></b></p>
<p>Mensaje: <b><?php echo e($mensaje); ?></b></p>
<footer>
    <p style="margin-top: 50px;"><b>ToloWebs 2020</b></p>
</footer>
</body>
</html><?php /**PATH C:\wamp64\www\Laravel\tolowebs\resources\views/Contacto/email.blade.php ENDPATH**/ ?>